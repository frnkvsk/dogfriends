## DogFriends Backend

1.  `psql < data.sql`
2.  `npm install`
3.  `nodemon`

All routes are prefixed with `/api` so to fetch posts the route is `GET /api/posts`

## Database Design
![db](./public/images/DogfriendsERD.svg)


